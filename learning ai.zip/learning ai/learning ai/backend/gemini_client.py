"""Talk to Google Gemini.

This file is the only place that calls the Gemini API.
The rest of the app asks this module for a reply.
"""

from google import genai
from google.genai import types

from backend.config import get_gemini_api_key, get_gemini_model

SYSTEM_INSTRUCTION = (
    "You are LEARNER AI. Tagline: Beyond Intelligence. Beyond Imagination. "
    "Be a clear, patient tutor. Explain ideas in simple language. "
    "If you are unsure, say so."
)


def _client() -> genai.Client:
    return genai.Client(api_key=get_gemini_api_key())


def generate_reply(message: str, history: list[dict]) -> str:
    """Send the user's message plus prior turns to Gemini.

    history items look like:
      {"role": "user", "content": "Hi"}
      {"role": "assistant", "content": "Hello"}
    """
    contents: list[types.Content] = []

    for turn in history:
        role = "user" if turn["role"] == "user" else "model"
        text = (turn.get("content") or "").strip()
        if not text:
            continue
        contents.append(
            types.Content(role=role, parts=[types.Part.from_text(text=text)])
        )

    contents.append(
        types.Content(role="user", parts=[types.Part.from_text(text=message)])
    )

    response = _client().models.generate_content(
        model=get_gemini_model(),
        contents=contents,
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_INSTRUCTION,
        ),
    )

    text = (response.text or "").strip()
    if not text:
        return "LEARNER AI did not return a reply. Try again in a moment."
    return text
