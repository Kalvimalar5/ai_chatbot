"""FastAPI server for LEARNER AI.

Run from the project root:
    .venv\\Scripts\\python -m uvicorn backend.main:app --reload
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from backend.gemini_client import generate_reply

app = FastAPI(
    title="LEARNER AI",
    description="Beyond Intelligence. Beyond Imagination.",
    version="0.1.0",
)

# Streamlit runs on another port, so the browser needs CORS permission.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8501", "http://localhost:8501"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatTurn(BaseModel):
    role: str = Field(description="user or assistant")
    content: str


class ChatRequest(BaseModel):
    message: str = Field(min_length=1)
    history: list[ChatTurn] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str


@app.get("/")
def health() -> dict:
    return {
        "app": "LEARNER AI",
        "tagline": "Beyond Intelligence. Beyond Imagination.",
        "phase": 1,
        "status": "ok",
    }


@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest) -> ChatResponse:
    try:
        history = [turn.model_dump() for turn in request.history]
        reply = generate_reply(request.message.strip(), history)
        return ChatResponse(reply=reply)
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Gemini request failed: {exc}",
        ) from exc
