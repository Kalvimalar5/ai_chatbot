"""Streamlit chat UI for LEARNER AI.

Run from the project root (with the FastAPI server already running):
    .venv\\Scripts\\streamlit run frontend/app.py
"""

import os
from pathlib import Path

import httpx
import streamlit as st
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

st.set_page_config(page_title="LEARNER AI", page_icon="✦", layout="centered")

st.title("LEARNER AI")
st.caption("Beyond Intelligence. Beyond Imagination.")

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])


def ask_backend(user_text: str, history: list[dict]) -> str:
    payload = {
        "message": user_text,
        "history": history,
    }
    try:
        response = httpx.post(f"{BACKEND_URL}/chat", json=payload, timeout=60.0)
        response.raise_for_status()
        return response.json()["reply"]
    except httpx.ConnectError:
        return (
            "Cannot reach the backend. In another terminal, start FastAPI:\n\n"
            "`.venv\\Scripts\\python -m uvicorn backend.main:app --reload`"
        )
    except httpx.HTTPStatusError as exc:
        detail = exc.response.json().get("detail", exc.response.text)
        return f"Backend error: {detail}"
    except Exception as exc:
        return f"Something went wrong: {exc}"


prompt = st.chat_input("Ask LEARNER AI anything...")

if prompt:
    prior_history = list(st.session_state.messages)
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            reply = ask_backend(prompt, prior_history)
        st.markdown(reply)

    st.session_state.messages.append({"role": "assistant", "content": reply})
