# LEARNER AI

**Beyond Intelligence. Beyond Imagination.**

A Python chatbot that talks to Google Gemini. This README covers **Phase 1 only**: project setup and a basic chat. PDF upload, ChromaDB, and citations come in later phases after this chat works.

## What you are building (in phases)

| Phase | What we add | Status |
|-------|-------------|--------|
| 1 | Project setup + Gemini chat (FastAPI + Streamlit) | You are here |
| 2 | Chat history polish / error handling if needed | After Phase 1 works |
| 3 | Upload PDFs | Later |
| 4 | Ask questions about PDFs with ChromaDB | Later |
| 5 | Show document citations | Later |

## Tools used

- **Python** — the programming language
- **FastAPI** — a small web server that talks to Gemini
- **Streamlit** — the chat window you type in
- **Gemini API** — Google's AI model
- **`.env`** — a private file that stores your API key

## 1. Get a Gemini API key

1. Open [Google AI Studio](https://aistudio.google.com/apikey).
2. Sign in with your Google account.
3. Create an API key.
4. Copy the key.

## 2. Put the key in `.env` (never share it)

Open the file named `.env` in this project and paste your key:

```
GEMINI_API_KEY=paste_your_real_key_here
GEMINI_MODEL=gemini-2.0-flash
BACKEND_URL=http://127.0.0.1:8000
```

Save the file. `.env` is listed in `.gitignore`, so Git will not upload your key.

## 3. Create a virtual environment and install packages

A virtual environment is a private folder of Python libraries for this project only.

In PowerShell, from this project folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

If Windows blocks the activate script, run this once, then try activate again:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

## 4. Start the backend (Terminal 1)

```powershell
.\.venv\Scripts\python -m uvicorn backend.main:app --reload
```

You should see something like `Uvicorn running on http://127.0.0.1:8000`.

Open http://127.0.0.1:8000 in a browser. You should see JSON with `"status": "ok"`.

## 5. Start the chat UI (Terminal 2)

Keep Terminal 1 running. Open a second PowerShell in the same folder:

```powershell
.\.venv\Scripts\Activate.ps1
.\.venv\Scripts\streamlit run frontend/app.py
```

A browser tab should open (usually http://localhost:8501). Type a message and wait for LEARNER AI to reply.

## How the pieces connect

```
You type in Streamlit  -->  FastAPI /chat  -->  Gemini API  -->  reply shown in the chat
```

- `frontend/app.py` is the chat window. It keeps messages in Streamlit session state (history while the tab is open).
- `backend/main.py` is the API. It receives your message and previous turns.
- `backend/gemini_client.py` sends that conversation to Gemini.
- `backend/config.py` reads your key from `.env`.

## If something goes wrong

| Problem | What to try |
|---------|-------------|
| `GEMINI_API_KEY is missing` | Put a real key in `.env` and save. Restart the backend. |
| Cannot reach the backend | Start uvicorn in Terminal 1 first, then Streamlit. |
| Gemini request failed | Check the key, internet, and that the model name in `.env` is valid. |
| Streamlit won't start | Confirm you ran `pip install -r requirements.txt` inside `.venv`. |

Do not move to PDF upload until a normal chat reply works in the browser.
